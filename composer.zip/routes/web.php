<?php

use App\Models\AddJournal;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\SignupController;
use App\Http\Controllers\CfpDataController;
use App\Http\Controllers\PostCfpController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\AddJournalController;
use App\Http\Controllers\Auth\AuthController; 
use App\Http\Controllers\JournalDataController;
use App\Http\Controllers\ForgetPasswordController;
use App\Http\Controllers\BusinessSettingController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\Auth\ForgotPasswordController;

Route::get('/journals', [UserController::class, 'index']);
Route::get('user/login', [UserController::class, 'login'])->name('user.login');
Route::get('user/promote', [UserController::class, 'promote'])->name('user.promote');
Route::get('user/add', [UserController::class, 'add'])->name('user.add'); 
Route::get('user/search', [UserController::class, 'search'])->name('user.search'); 
Route::get('contact', [UserController::class, 'contact'])->name('user.contact'); 

Route::post('dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
Route::get('admin/login', [AdminController::class, 'adminLogin'])->name('admin.login');
Route::group(['prefix' => 'admin', 'as' => 'admin.', 'middleware' => 'admin'], function () {
    Route::get('dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
});
Route::get('login', [LoginController::class, 'login'])->name('user.login');

Route::get('dashboard/addjournal/index', [AddJournalController::class, 'index'])->name('dashboard.addjournal.index');
Route::get('admin/edit', [BusinessSettingController::class, 'edit'])->name('admin.edit');
Route::post('admin/edit', [BusinessSettingController::class, 'update'])->name('admin.update');

Route::get('user/add/create', [AddJournalController::class, 'create'])->name('user.add.create');
Route::post('user/add/store', [AddJournalController::class, 'store'])->name('user.add.store');

Route::get('/search', [SearchController::class, 'search'])->name('user.search');

Route::get('/country-list', [AddJournalController::class, 'countryList'])->name('countryList');

Route::get('user/create', [SignupController::class, 'create'])->name('user.create');
Route::post('user/register', [SignupController::class, 'register'])->name('user.register');
Route::get('verify-email/{token}', [SignupController::class, 'verifyEmail'])->name('verify.email');

Route::get('/reset', [ForgotPasswordController::class, 'showLinkRequestForm']);

Route::post('/forgot-password', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::get('/reset-password/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('/reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');

Route::get('/postcfp', [PostCfpController::class, 'create'])->name('user.postcfp');
Route::post('/indexpostcfp', [PostCfpController::class, 'index'])->name('user.index');

Route::get('/data', [JournalDataController::class, 'create'])->name('user.create');
Route::post('user/data/store', [JournalDataController::class, 'store'])->name('user.data.store');

//  Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
// Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::get('login', [RegisterController::class, 'showLoginForm'])->name('login');
Route::get('registration', [RegisterController::class, 'registration'])->name('register');
Route::post('registration', [RegisterController::class, 'store'])->name('register.store');



// Email verification routes
Route::get('/email/verify/{id}/{hash}', [RegisterController::class, 'verifyEmail'])->name('verification.verify');
Route::get('/email/verify', [RegisterController::class, 'showVerificationNotice'])->name('verification.notice');
Route::get('/email/resend', [RegisterController::class, 'resendVerificationEmail'])->name('verification.resend');

