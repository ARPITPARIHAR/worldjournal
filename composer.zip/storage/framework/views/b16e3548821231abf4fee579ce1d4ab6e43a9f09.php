<h1>Email Verification Mail</h1>

<p>Please verify your email with the link below:</p>

<a href="<?php echo e($verificationUrl); ?>">Verify Email</a>


<?php /**PATH C:\xampp\htdocs\journal\journal\resources\views/emails/verify.blade.php ENDPATH**/ ?>