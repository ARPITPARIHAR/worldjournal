
<?php $__env->startSection('meta_title','login'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container log" style="margin-top: 130px; margin-bottom: 70px;">
  <div class="row justify-content-center">
      <div class="col-md-8">
          <div class="card">
     
              <div class="card-header text-center" style="background-color: #f0f0f0;">Login</div>
              <div class="card-body">
                  <form method="POST" action="<?php echo e(route('login')); ?>">
                      <?php echo csrf_field(); ?>

                      <div class="form-group row">
                          <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email Address')); ?></label>

                          <div class="col-md-6">
                              <input id="email" type="email" class="form-control " name="email" value="" required autocomplete="email" autofocus><br>

                            
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                          <div class="col-md-6">
                              <input id="password" type="password" class="form-control" name="password" required autocomplete="current-password"><br>

                            
                          </div>
                      </div>

                      <div class="form-group row">
                          <div class="col-md-6 offset-md-4">
                              <div class="form-check">
                                  <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                  <label class="form-check-label" for="remember">
                                      <?php echo e(__('Remember Me')); ?>

                                  </label>
                              </div>
                          </div>
                      </div>
<br>
                      <div class="form-group row mb-0">
                          <div class="col-md-8 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  <?php echo e(__('Login')); ?>

                              </button>
                          </div>
                      </div>
                  </form>
                  
                  <div class="form-group row mb-0">
                      <div class="col-md-8 offset-md-4">
                      
                              <a class="btn btn-link" href="/reset">
                                  <?php echo e(__('Forgot Your Password?')); ?>

                              </a>
                        
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

<?php echo $__env->make('user.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\journal\resources\views/auth/login.blade.php ENDPATH**/ ?>