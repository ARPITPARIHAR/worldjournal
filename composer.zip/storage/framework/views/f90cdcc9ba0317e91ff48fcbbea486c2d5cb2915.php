
<?php $__env->startSection('meta_title', 'login'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container my-5">
  <div class="row">
    <div class="col-md-8 mx-auto">
      <div class="contsec my-5">
        <form action="<?php echo e(route('user.index')); ?>" method="post" class="needs-validation" novalidate>
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="fullname">Full Title:</label>
            <input name="fullname" type="text" class="form-control" id="fullname" placeholder="Enter Full Title" required>
            <div class="invalid-feedback">Please enter the Full Title.</div>
          </div>
          <div class="form-group">
            <label for="shortname">Short Title - Year:</label>
            <div class="input-group">
              <input name="shortname" type="text" class="form-control" id="shortname" placeholder="Enter Short Title" required>
              <div class="input-group-append">
                <span class="input-group-text">-</span>
              </div>
              <input name="year" type="text" class="form-control" id="year" placeholder="Enter Year" value="2023" required>
            </div>
            <div class="invalid-feedback">Please enter the Short Title and Year.</div>
            <small class="text-muted">For example: SIGIR - 2009</small>
          </div>
          <div class="form-group text-center">
            <button type="submit" class="btn btn-primary">Next</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('user.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\journal\resources\views/user/postcfp.blade.php ENDPATH**/ ?>