
<?php $__env->startSection('meta_title','journal'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="ind-cont">
<div class="col-md-1 text-center" style="margin-top: 25px; margin-left: 10px;">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e(asset('Image/'.$item->image)); ?>" width="120px" height="80px"class="image-gap">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
  <div class="col-lg-8 col-md-6 text-left ici-info-box"  style="margin-left: 1px;">
    <dl class="dl-horizontal xnomb" style="font-size: 13px";>
       
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <dt class="ng-binding journal-title">Journal title:</dt>
      <dd><?php echo e($item->journal_title); ?></dd>
      <dt class="ng-binding">ISSN:</dt>
      <dd><?php echo e($item->issn); ?></dd>
      <dt class="ng-binding">DOI:</dt>
      <dd><?php echo e($item->doi); ?></dd>
      <dt class="ng-binding">Website:</dt>
      <dd><?php echo e($item->website); ?></dd>
      <dt class="ng-binding">Country:</dt>
      <dd><?php echo e($item->country); ?></dd>
      <dt class="ng-binding">Publisher:</dt>
      <dd><?php echo e($item->publication_language); ?></dd>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </dl>
  </div>
</div>
<div class="col-lg-8 col-md-6 text-left ici-info-box">
  
    <div class="tab-header">
      <button class="tab-button" data-tab="tab1">Description</button>
      <button class="tab-button" data-tab="tab2">Details</button>
      <button class="tab-button" data-tab="tab3">Scientific profile</button>
      <button class="tab-button" data-tab="tab4">Publisher</button>
    </div>
  
    <div class="tab-content">
      <div id="tab1" class="tab-pane">
        <!-- Content for Tab 1 -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <dd><?php echo e($item->journal_description); ?></dd>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  
    <div class="tab-content">
      <div id="tab2" class="tab-pane">
        <table class="table table-bordered table-striped attractive-table">
          <thead>
            <tr>
              <th class="text-center">English title</th>
              <th class="text-center">Short title</th>
              <th class="text-center">Printed version</th>
              <th class="text-center">Electronic version</th>
              <th class="text-center">Publication frequency</th>
              <th class="text-center">Free full text</th>
              <th class="text-center">Journal character</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_object($item)): ?>
            <tr>
              <td class="text-center"><?php echo e($item->english_title); ?></td>
              <td class="text-center"><?php echo e($item->short_title); ?></td>
              <td class="text-center"><?php echo e($item->printed_version ? 'Yes' : 'No'); ?></td>
              <td class="text-center"><?php echo e($item->electronic_version ? 'Yes' : 'No'); ?></td>
              <td class="text-center"><?php echo e($item->published_frequency); ?></td>
              <td class="text-center"><?php echo e($item->free_full_texts ? 'Yes' : 'No'); ?></td>
              <td class="text-center"><?php echo e($item->journal_character ? 'Yes' : 'No'); ?></td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  
    <div class="tab-content">
      <div id="tab3" class="tab-pane">
        <table class="table table-bordered table-striped attractive-table">
          <thead>
            <tr>
              <th class="text-center">Scimago category</th>
              <th class="text-center">Web of science category</th>
              <th class="text-center">Indexed In</th>
              <th class="text-center">Circulation</th>
              <th class="text-center">Journal Type</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_object($item)): ?>
            <tr>
              <td class="text-center"><?php echo e($item->scimago_category); ?></td>
              <td class="text-center"><?php echo e($item->webofscience); ?></td>
              <td class="text-center"><?php echo e($item->indexing ? 'Yes' : 'No'); ?></td>
              <td class="text-center"><?php echo e($item->circulation ? 'Yes' : 'No'); ?></td>
              <td class="text-center"><?php echo e($item->circulation ? 'Yes' : 'No'); ?></td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  
    <div id="tab4" class="tab-pane">
      <dl>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_object($item)): ?>
        <dt>Publication Language:</dt>
        <dd><?php echo e($item->publication_language); ?></dd>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </dl>
    </div>
  </div>

  <?php echo $__env->make('user.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
 

 
      


      
  <?php $__env->startSection('style'); ?>
  <style>
    .footer-name {
  font-size: 16px; /* Adjust the value as per your preference */
}

    .ind-cont{
      margin-top:100px;
    }
    .attractive-header {
      font-family: "Your Desired Font", sans-serif;
      color: lightblue; /* Replace with your desired color code */
    }
  
    .table-responsive table {
      border-collapse: collapse;
    }
  
    .table-responsive th,
    .table-responsive td {
      border: none;
      padding: 5px;
    }
  
    .table-responsive th {
      text-align: right;
      width: 150px;
    }
  
    .table-responsive td {
      margin-top: -70px;
    }
  
    .table-responsive tr {
      margin-bottom: -160px;
    }
  
    .table-responsive .image-cell {
      display: grid;
      align-items: center;
      justify-content: flex-start;
      gap: 10px;
    }
  
    .table-responsive .image-cell img {
      max-width: 100%;
      height: auto;
    }
  
    .tab-pane {
      display: none;
      font-size:13px;
    }
 

  
    .attractive-table {
      border-collapse: collapse;
      width: 900px;
    }
  
    .attractive-table thead th {
      background-color: powderblue;
      padding: 10px;
      text-align: left;
      font-weight: bold;
      color: #333;
    }
  
    .attractive-table tbody td {
      padding: 10px;
    }
  
   
  
    /* Custom styling for the tab container */
    .tab-container {
      border: 1px solid #ddd;
      background-color: olivedrab;
      padding: 10px;
      font-size:13px;
    }
  
    .tab-header {
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
  }

  .tab-button {
    padding: 10px 20px;
    background-color: purple;
    border: none;
    border-radius: 50px;
    margin-right: 10px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s;
    font-family: Arial, sans-serif;
    color: white;
    background: linear-gradient(to right,teal,	#8FBC8F);
    font-size: 13px;
  }

  .tab-button.active {
    background-color: purple;
    color: #333;
    background: darkkhaki;
  }
  body {
    display: flex;
    flex-direction: column;
    /* min-height: 100vh; */
  }

  .content-wrapper {
    flex: 1;
  }

  .footer {
    background-color: #f5f5f5;
    padding: 20px;
    text-align: center;
    margin-top: auto;
  }
  
   
    .journal-title {
    color: blue;
    
  }
 
    .image-gap {
    margin-bottom:60px; /* Adjust the margin as per your preference */
  }
  .table-spacing {
    margin-bottom: 40px; /* Adjust the margin as per your preference */
  }

  </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
    <script>
      const tabButtons = document.querySelectorAll('.tab-button');
      const tabPanes = document.querySelectorAll('.tab-pane');
    
      tabButtons.forEach(button => {
        button.addEventListener('click', () => {
          const tabId = button.getAttribute('data-tab');
          const tabPane = document.getElementById(tabId);
    
          // Toggle the visibility of the clicked tab content
          tabPanes.forEach(pane => {
            if (pane === tabPane) {
              pane.style.display = 'block';
            } else {
              pane.style.display = 'none';
            }
          });
    
          // Toggle the active class on the clicked tab button
          tabButtons.forEach(btn => {
            if (btn === button) {
              btn.classList.add('active');
            } else {
              btn.classList.remove('active');
            }
          });
        });
      });
    </script>  <?php $__env->stopSection(); ?> 
  
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\journal\resources\views/user/index.blade.php ENDPATH**/ ?>