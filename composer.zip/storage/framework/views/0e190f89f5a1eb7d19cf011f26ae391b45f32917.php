
<?php $__env->startSection('meta_title','postcfp'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('user.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="contsec">
  

    
   




  
  <form action="<?php echo e(route('user.index')); ?>" method="post"  class="needs-validation" novalidate>
    <?php echo csrf_field(); ?>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="form-group">
                <label for="fullname">Full Title:</label>
                <input name="fullname" type="text" class="form-control" id="fullname" placeholder="Enter Full Title" required>
                <div class="invalid-feedback">Please enter the Full Title.</div>
              </div>
              <div class="form-group">
                <label for="shortname">Short Title - Year:</label>
                <div class="input-group">
                  <input name="shortname" type="text" class="form-control" id="shortname" placeholder="Enter Short Title" required>
                  <div class="input-group-append">
                    <span class="input-group-text">-</span>
                  </div>
                  <input name="year" type="text" class="form-control" id="year" placeholder="Enter Year" value="2023" required>
                </div>
                <div class="invalid-feedback">Please enter the Short Title and Year.</div>
                <small class="text-muted">For example: SIGIR - 2009</small>
              </div>
              <div class="form-group text-center">
                <button type="submit" class="btn btn-primary">Next</button>
              </div>
            </div>
          </div>
        </div>
      </form>
      
              
    <a href=/fetch-journal-data onclick="openOkIndex(event)">Click Me</a>

<script>
  function openOkIndex(event) {
    event.preventDefault();
    window.location.href = event.target.getAttribute('href');
  }
</script>



    
</div>


<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css"></head>
    <style>
      /* Custom styling for the table */
      #tableContainer dl {
        padding: 20px;
        border: 1px solid #ccc;
        background-color: #f8f9fa;
      }
  
      #tableContainer dt {
        font-weight: bold;
      }
  
      #tableContainer dd {
        margin-bottom: 10px;
      }
    </style>
  </head>
  

  
  



 




<style>
   
    .dl-horizontal dt {
    padding-left: 20px;
}

   

.col-lg-8 {
    margin-top: 10px;
        position: relative;
        margin-bottom: 300px;
        margin-left: 50px;
    }
    .contsec{
        margin-top: 100px;
       
        margin-bottom:30px;
        border:1px solid;
        border-block: 10px;
    }
    </style>







<?php echo $__env->make('user.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\journal\journal\resources\views/user/postcfp.blade.php ENDPATH**/ ?>