<?php

namespace App\Http\Controllers;

use App\Models\Register;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    /**
     * Handle the registration form submission.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function showLoginForm()
    {
        return view('auth.login')->with('errors', $errors);
    }
    
    public function registration()
    {
        return view('auth.register');
    }

    public function store(Request $request)
    {
        // Validate the form data
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:register,email',
            'password' => 'required|string|min:8|confirmed',
        ]);
  
        // Create the user but mark them as unverified
        $user = Register::create([
            'name' => $validatedData['name'],
            'email' => $validatedData['email'],
            'password' => Hash::make($validatedData['password']),
        ]);

        // Trigger the email verification notification
        event(new Registered($user));

        // Redirect the user after successful registration
        return redirect()->route('login')->with('success', 'Registration successful! Please check your email for verification.');
    }

    /**
     * Verify the user's email address.
     *
     * @param  string  $id
     * @param  string  $hash
     * @return \Illuminate\Http\RedirectResponse
     */
    public function verifyEmail($id, $hash)
    {
        $user = Register::findOrFail($id);

        if ($user->hasVerifiedEmail()) {
            return redirect()->route('login')->with('warning', 'Your email address is already verified.');
        }

        if ($user->markEmailAsVerified()) {
            event(new \Illuminate\Auth\Events\Verified($user));
            Auth::login($user);
            return redirect()->route('home')->with('success', 'Email verified successfully!');
        }

        return redirect()->route('login')->with('error', 'Email verification failed. Please try again.');
    }
}
