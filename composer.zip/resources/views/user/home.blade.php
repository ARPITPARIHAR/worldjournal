@extends('user.layouts.app')
@section('meta_title','journal')
@section('content')
@include('user.includes.nav')
@include('user.includes.slider') 
@include('user.includes.header')
{{-- @include('user.includes.count') --}}
@include('user.includes.footer')
@endsection
@section('style')
    
@endsection
@section('script')
    
@endsection 